from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import time
import cv2
import numpy as np

# ---------------------------
# Reglages perf (manga)
# ---------------------------

PIPELINE_NAME = "OCR"          # change to your pipeline name if different (ex: "PP-OCRv4")
MAX_WIDTH_FOR_OCR = 2000       # higher width to keep text readable (was 1600)
CACHE_ENABLED = True
DEBUG_TIMINGS = True

# ---------------------------
# Types
# ---------------------------

Box = List[List[int]]              # [[x,y],[x,y],[x,y],[x,y]]
Result = Tuple[str, float, Box]    # (text, conf, box)


@dataclass
class OcrPack:
    img_for_merge: np.ndarray      # image used for OCR coords (after resize/preprocess)
    results: List[Result]          # boxes in the coords of img_for_merge
    orig_img: np.ndarray           # original image (full size)
    scale_to_orig: float           # factor to map OCR coords back to original


# ---------------------------
# Geometry utils
# ---------------------------

def _poly_to_aabb(poly: Box) -> Tuple[int, int, int, int]:
    xs = [p[0] for p in poly]
    ys = [p[1] for p in poly]
    return int(min(xs)), int(min(ys)), int(max(xs)), int(max(ys))


def _merge_polys(polys: List[Box]) -> Box:
    x1s: List[int] = []
    y1s: List[int] = []
    x2s: List[int] = []
    y2s: List[int] = []
    for poly in polys:
        x1, y1, x2, y2 = _poly_to_aabb(poly)
        x1s.append(x1)
        y1s.append(y1)
        x2s.append(x2)
        y2s.append(y2)
    x1, y1, x2, y2 = min(x1s), min(y1s), max(x2s), max(y2s)
    return [[x1, y1], [x2, y1], [x2, y2], [x1, y2]]


def _box_center(poly: Box) -> Tuple[float, float]:
    x1, y1, x2, y2 = _poly_to_aabb(poly)
    return (x1 + x2) / 2.0, (y1 + y2) / 2.0


def _inside(rect: Tuple[int, int, int, int], point: Tuple[float, float], pad: int = 0) -> bool:
    x1, y1, x2, y2 = rect
    px, py = point
    return (x1 - pad) <= px <= (x2 + pad) and (y1 - pad) <= py <= (y2 + pad)


# ---------------------------
# Image utils (perf)
# ---------------------------

def _resize_for_ocr(img_bgr: np.ndarray, max_width: int) -> Tuple[np.ndarray, float]:
    """
    Resize if too wide.
    Returns (img_resized, scale) where scale = new_w / old_w.
    """
    h, w = img_bgr.shape[:2]
    if w <= max_width:
        return img_bgr, 1.0

    scale = max_width / float(w)
    new_w = int(w * scale)
    new_h = int(h * scale)

    resized = cv2.resize(img_bgr, (new_w, new_h), interpolation=cv2.INTER_AREA)
    return resized, scale


def _scale_box(box: Box, scale: float) -> Box:
    if scale == 1.0:
        return box
    out: Box = []
    for x, y in box:
        out.append([int(round(x * scale)), int(round(y * scale))])
    return out


def _scale_box_xy(box: Box, sx: float, sy: float) -> Box:
    if abs(sx - 1.0) < 1e-6 and abs(sy - 1.0) < 1e-6:
        return box
    out: Box = []
    for x, y in box:
        out.append([int(round(x * sx)), int(round(y * sy))])
    return out


# ---------------------------
# Bubble detection (level 2)
# ---------------------------

def _detect_bubble_candidates(img_bgr: np.ndarray) -> List[Tuple[int, int, int, int]]:
    h, w = img_bgr.shape[:2]
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)

    # light areas -> bubbles often white
    _, th = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    white_ratio = float((th == 255).mean())
    if white_ratio < 0.35:
        th = cv2.bitwise_not(th)

    k = max(3, int(min(h, w) * 0.01))
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    closed = cv2.morphologyEx(th, cv2.MORPH_CLOSE, kernel, iterations=2)

    k2 = max(3, k // 2)
    kernel2 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k2, k2))
    cleaned = cv2.morphologyEx(closed, cv2.MORPH_OPEN, kernel2, iterations=1)

    contours, _ = cv2.findContours(cleaned, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    rects: List[Tuple[int, int, int, int]] = []
    min_area = (h * w) * 0.002
    max_area = (h * w) * 0.60

    for c in contours:
        x, y, cw, ch = cv2.boundingRect(c)
        area = cw * ch
        if area < min_area or area > max_area:
            continue

        ar = cw / max(1, ch)
        if ar > 12 or ar < 0.08:
            continue

        pad = int(min(h, w) * 0.005)
        x1 = max(0, x - pad)
        y1 = max(0, y - pad)
        x2 = min(w - 1, x + cw + pad)
        y2 = min(h - 1, y + ch + pad)
        rects.append((x1, y1, x2, y2))

    rects.sort(key=lambda r: (r[1], r[0]))
    return rects


def _fallback_cluster_lines(results: List[Result]) -> List[Result]:
    if not results:
        return []

    items: List[Tuple[int, int, str, float, Box, Tuple[int, int, int, int]]] = []
    for text, conf, poly in results:
        x1, y1, x2, y2 = _poly_to_aabb(poly)
        items.append((y1, x1, text, conf, poly, (x1, y1, x2, y2)))
    items.sort()

    merged: List[Result] = []
    used = [False] * len(items)

    for i in range(len(items)):
        if used[i]:
            continue

        _y1, _x1, text, conf, poly, rect = items[i]
        used[i] = True

        gx1, gy1, gx2, gy2 = rect
        gtext = [text]
        gconf = [conf]
        gpolys = [poly]

        line_h = (gy2 - gy1)
        max_dy = max(10, int(line_h * 1.6))

        for j in range(i + 1, len(items)):
            if used[j]:
                continue

            _y1b, _x1b, textb, confb, polyb, rectb = items[j]
            bx1, by1, bx2, by2 = rectb

            if abs(by1 - gy2) > max_dy and abs(by1 - gy1) > max_dy:
                continue

            overlap = max(0, min(gx2, bx2) - max(gx1, bx1))
            minw = max(1, min(gx2 - gx1, bx2 - bx1))
            if overlap / minw < 0.15:
                continue

            used[j] = True
            gtext.append(textb)
            gconf.append(confb)
            gpolys.append(polyb)

            gx1 = min(gx1, bx1)
            gy1 = min(gy1, by1)
            gx2 = max(gx2, bx2)
            gy2 = max(gy2, by2)

        merged_poly = _merge_polys(gpolys)
        merged_text = " ".join(gtext)
        merged_conf = float(np.mean(gconf)) if gconf else 0.0
        merged.append((merged_text, merged_conf, merged_poly))

    return merged


def _merge_by_bubbles(img_bgr: np.ndarray, results: List[Result]) -> List[Result]:
    if not results:
        return []

    bubble_rects = _detect_bubble_candidates(img_bgr)
    if not bubble_rects:
        return _fallback_cluster_lines(results)

    assigned: Dict[int, List[Result]] = {}
    unassigned: List[Result] = []

    for text, conf, poly in results:
        cx, cy = _box_center(poly)

        found_idx: Optional[int] = None
        for idx, rect in enumerate(bubble_rects):
            if _inside(rect, (cx, cy), pad=8):
                found_idx = idx
                break

        if found_idx is None:
            unassigned.append((text, conf, poly))
        else:
            assigned.setdefault(found_idx, []).append((text, conf, poly))

    merged: List[Result] = []

    for _, group in assigned.items():
        group_sorted = sorted(group, key=lambda r: _poly_to_aabb(r[2])[1])

        texts = [t for (t, _c, _p) in group_sorted]
        confs = [c for (_t, c, _p) in group_sorted]
        polys = [p for (_t, _c, p) in group_sorted]

        merged_text = " ".join(texts).strip()
        merged_conf = float(np.mean(confs)) if confs else 0.0
        merged_poly = _merge_polys(polys)

        merged.append((merged_text, merged_conf, merged_poly))

    if unassigned:
        merged.extend(_fallback_cluster_lines(unassigned))

    merged.sort(key=lambda r: _poly_to_aabb(r[2])[1])
    return merged


# ---------------------------
# Normalisation RAW (Pylance-safe)
# ---------------------------

def _first_mapping(obj: Any) -> Mapping[str, Any]:
    if isinstance(obj, Mapping):
        return obj
    if isinstance(obj, (list, tuple)) and obj:
        head = obj[0]
        if isinstance(head, Mapping):
            return head
    return {}


def _safe_get(mapping: Mapping[str, Any], key: str, default: Any) -> Any:
    try:
        return mapping.get(key, default)
    except Exception:
        return default


def _to_box(poly: Any) -> Optional[Box]:
    if poly is None:
        return None
    if hasattr(poly, "tolist"):
        poly = poly.tolist()
    if not isinstance(poly, list) or len(poly) < 4:
        return None

    out: Box = []
    for p in poly[:4]:
        if not isinstance(p, (list, tuple)) or len(p) < 2:
            return None
        out.append([int(p[0]), int(p[1])])
    return out


def _parse_results_from_raw(raw: Any) -> Tuple[Optional[np.ndarray], List[Result]]:
    """
    Support PaddleX-like RAW:
      raw = [ { 'rec_texts': [...], 'rec_scores': [...], 'rec_polys': [...],
                'doc_preprocessor_res': {'output_img': ...} } ]
    """
    d = _first_mapping(raw)

    doc_pre = _safe_get(d, "doc_preprocessor_res", {})
    output_img = _safe_get(doc_pre, "output_img", None) if isinstance(doc_pre, Mapping) else None
    last_output_img = output_img if isinstance(output_img, np.ndarray) else None

    rec_texts = _safe_get(d, "rec_texts", []) or []
    rec_scores = _safe_get(d, "rec_scores", []) or []
    rec_polys = _safe_get(d, "rec_polys", []) or []

    if not isinstance(rec_texts, Sequence):
        rec_texts = []
    if not isinstance(rec_scores, Sequence):
        rec_scores = []
    if not isinstance(rec_polys, Sequence):
        rec_polys = []

    results: List[Result] = []
    for t, s, p in zip(rec_texts, rec_scores, rec_polys):
        box = _to_box(p)
        if box is None:
            continue
        try:
            text = str(t)
        except Exception:
            text = ""
        try:
            score = float(s)
        except Exception:
            score = 0.0
        if text.strip():
            results.append((text, score, box))

    return last_output_img, results


# ---------------------------
# OCRService (avec optimisations + GPU auto)
# ---------------------------

class OCRService:
    def __init__(self):
        self._cache: Dict[str, OcrPack] = {}
        self.last_output_img: Optional[np.ndarray] = None

        self.pipeline: Any | None = None  # loaded once
        self._pipeline_device: str | None = None  # for logs only

    def prepare_preview(self, image_path: str, lang_code: str):
        """
        Returns the preprocessed image used for OCR (resize + preprocess),
        to display right after loading (avoid change before/after).
        """
        img_bgr = cv2.imread(image_path)
        if img_bgr is None:
            raise RuntimeError(f"Impossible de lire l'image: {image_path}")

        # Reuse exact same logic as run()
        img_for_ocr, _scale = _resize_for_ocr(img_bgr, MAX_WIDTH_FOR_OCR)

        # If you add preprocess steps, apply them here too.
        # img_for_ocr = self._preprocess_for_ocr(img_for_ocr, lang_code)

        return img_for_ocr

    def _ensure_pipeline(self) -> None:
        if self.pipeline is not None:
            return

        from paddlex import create_pipeline

        # GPU detection (lazy import paddle, fallback CPU)
        def detect_device() -> tuple[bool, str]:
            try:
                import paddle

                compiled = bool(getattr(paddle, "is_compiled_with_cuda", lambda: False)())
                if not compiled:
                    return False, "cpu"

                cuda = getattr(getattr(paddle, "device", None), "cuda", None)
                if cuda is None:
                    return False, "cpu"

                device_count = getattr(cuda, "device_count", None)
                if device_count is None:
                    return False, "cpu"

                has_gpu = device_count() > 0
                return has_gpu, ("gpu:0" if has_gpu else "cpu")
            except Exception:
                return False, "cpu"

        use_gpu, device = detect_device()

        try:
            self.pipeline = create_pipeline(pipeline=PIPELINE_NAME, device=device)
            self._pipeline_device = device
            print(f"PaddleX device = {device}")
        except TypeError:
            try:
                self.pipeline = create_pipeline(pipeline=PIPELINE_NAME, use_gpu=use_gpu)
                self._pipeline_device = "gpu:0" if use_gpu else "cpu"
                print(f"PaddleX use_gpu = {use_gpu}")
            except Exception as e:
                print("GPU init failed (TypeError fallback), switching CPU:", e)
                self.pipeline = create_pipeline(pipeline=PIPELINE_NAME)
                self._pipeline_device = "cpu"
                print("PaddleX device = cpu (fallback)")
        except Exception as e:
            print("GPU unavailable, fallback CPU:", e)
            self.pipeline = create_pipeline(pipeline=PIPELINE_NAME, device="cpu")
            self._pipeline_device = "cpu"
            print("PaddleX device = cpu (fallback)")

        assert self.pipeline is not None

    def _your_pipeline_call(self, img_input: Any, lang_code: str):
        self._ensure_pipeline()

        pipeline = self.pipeline
        assert pipeline is not None  # for type checker

        raw = pipeline.predict(img_input)

        if not isinstance(raw, list):
            raw = list(raw)

        return raw

    def _run_raw_ocr(self, img_path: str, lang_code: str) -> OcrPack:
        t0 = time.perf_counter()

        # Cache (if you run the same image multiple times)
        cache_key = f"{img_path}|{lang_code}|w{MAX_WIDTH_FOR_OCR}"
        if CACHE_ENABLED and cache_key in self._cache:
            if DEBUG_TIMINGS:
                print("Cache hit (OCR) -> instant")

            pack = self._cache[cache_key]
            # show OCR/preprocessed image (coords align with boxes)
            self.last_output_img = pack.img_for_merge
            return pack

        # Read image
        img_bgr = cv2.imread(img_path, cv2.IMREAD_COLOR)
        if img_bgr is None:
            raise RuntimeError(f"Impossible de lire l'image: {img_path}")

        t_read = time.perf_counter()

        # Resize for speed
        img_for_ocr, scale = _resize_for_ocr(img_bgr, MAX_WIDTH_FOR_OCR)
        scale_to_orig = 1.0 / float(scale) if scale != 0 else 1.0

        t_resize = time.perf_counter()

        # OCR raw
        raw = self._your_pipeline_call(img_for_ocr, lang_code)

        t_ocr = time.perf_counter()

        out_img, results = _parse_results_from_raw(raw)

        # The boxes are in the referential of out_img if it exists, else img_for_ocr
        img_for_merge = out_img if out_img is not None else img_for_ocr

        t_parse = time.perf_counter()

        pack = OcrPack(
            img_for_merge=img_for_merge,
            results=results,
            orig_img=img_bgr,
            scale_to_orig=scale_to_orig,
        )

        if CACHE_ENABLED:
            self._cache[cache_key] = pack

        if DEBUG_TIMINGS:
            print(
                "Timings:",
                f"read={(t_read - t0)*1000:.0f}ms |",
                f"resize={(t_resize - t_read)*1000:.0f}ms |",
                f"ocr={(t_ocr - t_resize):.2f}s |",
                f"parse={(t_parse - t_ocr)*1000:.0f}ms |",
                f"total={(t_parse - t0):.2f}s |",
                f"scale={scale:.3f} |",
                f"device={self._pipeline_device}",
            )

        return pack

    def run(self, img_path: str, lang_code: str) -> List[Result]:
        pack = self._run_raw_ocr(img_path, lang_code)

        # Merge level 2 (bubbles)
        t0 = time.perf_counter()
        merged = _merge_by_bubbles(pack.img_for_merge, pack.results)
        t1 = time.perf_counter()

        if DEBUG_TIMINGS:
            print(f"fusion={(t1 - t0)*1000:.0f}ms | lines={len(pack.results)} -> merged={len(merged)}")

        # Show the OCR/preprocessed image directly so boxes stay aligned 1:1
        self.last_output_img = pack.img_for_merge

        return merged
