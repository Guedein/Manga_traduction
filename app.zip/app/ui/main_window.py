# app/ui/main_window.py
from __future__ import annotations


from pathlib import Path
from typing import Optional, List, Tuple, cast

from PySide6.QtCore import Qt, QThread, Signal, QObject
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QPushButton, QComboBox, QProgressBar, QLabel,
    QFileDialog, QHBoxLayout, QVBoxLayout, QSplitter, QGroupBox, QLineEdit, QCheckBox
)

from app.ui.widgets.image_viewer import ImageViewer
from app.ui.widgets.log_panel import LogPanel
from app.services.ocr_service import OCRService
from app.services.translate_service import TranslateService
from app.services.translate_service import TranslatorMode


# (text, conf, box)
OcrResult = Tuple[str, float, list]


class OCRTranslateWorker(QObject):
    finished = Signal(list, list)  # ocr_results, translations
    error = Signal(str)
    progress = Signal(int)

    def __init__(
        self,
        image_path: str,
        lang_code: str,
        ocr_service: OCRService,
        translate_service: TranslateService,
        translate_mode: TranslatorMode,
        api_key: str,
        src_lang_ui: str,
        tgt_lang_ui: str,
        auto_fallback: bool,
    ):
        super().__init__()
        self.image_path = image_path
        self.lang_code = lang_code
        self.ocr_service = ocr_service
        self.translate_service = translate_service
        self.translate_mode = translate_mode
        self.api_key = api_key
        self.src_lang_ui = src_lang_ui
        self.tgt_lang_ui = tgt_lang_ui
        self.auto_fallback = auto_fallback

    def run(self):
        try:
            self.progress.emit(5)

            # 1) OCR
            ocr_results: List[OcrResult] = self.ocr_service.run(self.image_path, self.lang_code)
            self.progress.emit(70)

            # 2) Traduction
            texts = [t for (t, _c, _b) in ocr_results]
            translations: List[str] = []

            if texts:
    # 🔒 Normalisation du mode (évite l’erreur Pylance str vs Literal)
                mode_txt = (self.translate_mode or "").strip().lower()
                mode: TranslatorMode = "online" if mode_txt == "online" else "local"

                self.translate_service.set_settings(
                    mode=mode,
                    api_key=self.api_key,
                    src_lang=self.src_lang_ui,
                    tgt_lang=self.tgt_lang_ui,
                    auto_fallback_to_local=bool(self.auto_fallback and (self.api_key or "").strip()),
                    provider="deepl",
                )

                translations = self.translate_service.translate_many(texts)


            self.progress.emit(100)
            self.finished.emit(ocr_results, translations)

        except Exception as e:
            self.error.emit(str(e))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Manga Translator - UI minimale + OCR")
        self.resize(1100, 700)

        self.current_image_path: Optional[str] = None

        # OCR service
        self.ocr_service = OCRService()

        # Traduction service
        self.translate_service = TranslateService()

        # --- Widgets top controls ---
        self.btn_choose = QPushButton("Choisir une image")
        self.btn_run = QPushButton("Lancer (OCR)")
        self.btn_run.setEnabled(False)

        self.lang_combo = QComboBox()
        self.lang_map = {
            "Auto": "auto",
            "EN": "en",
            "CH": "ch",
            "JP": "jp",
            "KR": "kr",
        }
        self.lang_combo.addItems(list(self.lang_map.keys()))

        # --- Traduction (choix A/B) ---
        self.translate_mode_combo = QComboBox()
        self.translate_mode_combo.addItems(["Online (API)", "Local (offline)"])

        self.api_key_edit = QLineEdit()
        self.api_key_edit.setPlaceholderText("Cle API (DeepL) - visible seulement en Online")
        self.api_key_edit.setEchoMode(QLineEdit.EchoMode.Password)

        self.fallback_chk = QCheckBox("Fallback auto Online → Local")
        self.fallback_chk.setChecked(True)

        self.tgt_lang_ui = "FR"

        self.mode_label = QLabel("Mode : Pro")
        self.mode_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)

        # --- Preview + Logs ---
        self.image_viewer = ImageViewer()
        self.image_viewer.set_view_mode("fit")    # avoid crop, keep full image
        self.logs = LogPanel()

        # --- Layout build ---
        root = QWidget()
        self.setCentralWidget(root)

        top_left = QHBoxLayout()
        top_left.addWidget(self.btn_choose)
        top_left.addWidget(self.btn_run)

        top_right = QHBoxLayout()
        top_right.addWidget(QLabel("Langue source :"))
        top_right.addWidget(self.lang_combo)

        top_right.addSpacing(18)
        top_right.addWidget(QLabel("Traduction :"))
        top_right.addWidget(self.translate_mode_combo)
        top_right.addWidget(self.api_key_edit)
        top_right.addWidget(self.fallback_chk)

        top_right.addStretch(1)
        top_right.addWidget(self.mode_label)

        top_bar = QHBoxLayout()
        top_bar.addLayout(top_left)
        top_bar.addStretch(1)
        top_bar.addLayout(top_right)

        preview_group = QGroupBox("Preview image")
        preview_layout = QVBoxLayout(preview_group)
        preview_layout.setContentsMargins(0, 0, 0, 0)   # ✅
        preview_layout.setSpacing(0)                    # ✅
        preview_layout.addWidget(self.image_viewer)

        logs_group = QGroupBox("Logs")
        logs_layout = QVBoxLayout(logs_group)
        logs_layout.setContentsMargins(0, 0, 0, 0)      # ✅
        logs_layout.setSpacing(0)                       # ✅
        logs_layout.addWidget(self.logs)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(preview_group)
        splitter.addWidget(logs_group)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        splitter.setChildrenCollapsible(False)  # ✅ évite qu’un panneau s’écrase bizarrement
        splitter.setHandleWidth(8)              # optionnel, plus facile à choper
        splitter.setSizes([800, 300])           # ✅ preview plus large que logs


        main_layout = QVBoxLayout(root)
        main_layout.addLayout(top_bar)
        main_layout.addWidget(self.progress)
        main_layout.addWidget(splitter, 1)  # ✅ le "1" donne tout le stretch au splitter


        # --- Signals ---
        self.btn_choose.clicked.connect(self.on_choose_image)
        self.btn_run.clicked.connect(self.on_run_ocr)
        self.translate_mode_combo.currentIndexChanged.connect(self.on_translate_mode_changed)

        # --- Thread refs ---
        self._thread: Optional[QThread] = None
        self._worker: Optional[OCRTranslateWorker] = None

        # --- Initial logs ---
        self.logs.log("✅ App démarrée.")
        self.logs.log("➡️ Choisis une image, puis clique sur 'Lancer (OCR)'.")
        self.logs.log("ℹ️ Astuce: les rectangles sont alignés sur l'image pré-traitée (OCR), pas toujours sur l'originale.")
        self.logs.log("🗣️ Traduction: tu peux choisir Online (API) ou Local (offline).")

        self.on_translate_mode_changed(self.translate_mode_combo.currentIndex())

    # ---------------- UI Actions ----------------
    def on_translate_mode_changed(self, _idx: int):
        is_online = self.translate_mode_combo.currentIndex() == 0
        self.api_key_edit.setVisible(is_online)
        self.fallback_chk.setVisible(is_online)

    def on_choose_image(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Choisir une image",
            str(Path.cwd()),
            "Images (*.png *.jpg *.jpeg *.webp *.bmp)"
        )
        if not path:
            self.logs.log("ℹ️ Sélection annulée.")
            return

        self.current_image_path = path
        self.progress.setValue(0)
        self.btn_run.setEnabled(True)

        self.image_viewer.clear_boxes()

        # ✅ Solution A : afficher directement l'image pré-traitée OCR
        try:
            img_preview = self.ocr_service.prepare_preview(
                path,
                self.lang_combo.currentText()  # chez toi c’est le combo langue source
            )
            self.image_viewer.set_image_array(img_preview, bgr=True)
            self.logs.log("👁️ Preview OCR affichée (image pré-traitée).")
        except Exception as e:
            # Fallback sécurité : image originale
            self.logs.log(f"⚠️ Preview OCR impossible, image originale affichée ({e})")
            self.image_viewer.set_image(path)


        self.logs.log(f"🖼️ Image chargée : {path}")

    def on_run_ocr(self):
        if not self.current_image_path:
            self.logs.log("❌ Aucune image sélectionnée.")
            return

        ui_lang = self.lang_combo.currentText()
        lang_code = self.lang_map.get(ui_lang, "auto")

        # Traduction settings UI
        mode_str = "online" if self.translate_mode_combo.currentIndex() == 0 else "local"
        translate_mode = cast(TranslatorMode, mode_str)  # ✅ FIX Pylance (str -> Literal)

        api_key = self.api_key_edit.text().strip()
        auto_fallback = self.fallback_chk.isChecked()

        src_lang_ui = ui_lang if ui_lang != "Auto" else "EN"

        self.logs.log("🚀 OCR en cours… (la 1ère fois peut télécharger des modèles)")
        self.logs.log(f"   - Langue : {ui_lang}")
        self.logs.log(f"🌍 Traduction : {'Online (API)' if translate_mode == 'online' else 'Local (offline)'} → {self.tgt_lang_ui}")
        if translate_mode == "online" and not api_key:
            self.logs.log("⚠️ Online choisi mais clé API vide → risque d’échec (fallback local possible).")

        self.progress.setValue(0)
        self.btn_run.setEnabled(False)
        self.btn_choose.setEnabled(False)

        thread = QThread()
        worker = OCRTranslateWorker(
            image_path=self.current_image_path,
            lang_code=lang_code,
            ocr_service=self.ocr_service,
            translate_service=self.translate_service,
            translate_mode=translate_mode,
            api_key=api_key,
            src_lang_ui=src_lang_ui,
            tgt_lang_ui=self.tgt_lang_ui,
            auto_fallback=auto_fallback,
        )
        worker.moveToThread(thread)

        thread.started.connect(worker.run)
        worker.progress.connect(self.progress.setValue)
        worker.finished.connect(self.on_ocr_translate_finished)
        worker.error.connect(self.on_ocr_error)

        # Clean
        worker.finished.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)

        worker.error.connect(thread.quit)
        worker.error.connect(worker.deleteLater)

        self._thread = thread
        self._worker = worker
        thread.start()

    # ---------------- OCR Callbacks ----------------
    def on_ocr_translate_finished(self, results: list, translations: list):
        self.btn_run.setEnabled(True)
        self.btn_choose.setEnabled(True)

        out_img = self.ocr_service.last_output_img
        self.image_viewer.clear_boxes()

        if out_img is not None:
            try:
                self.image_viewer.set_image_array(out_img, bgr=True)
            except Exception:
                if self.current_image_path:
                    self.image_viewer.set_image(self.current_image_path)
        else:
            if self.current_image_path:
                self.image_viewer.set_image(self.current_image_path)

        if not results:
            self.logs.log("⚠️ OCR fini, mais aucun texte détecté.")
            return

        boxes = [box for (_text, _conf, box) in results]
        self.image_viewer.set_boxes(boxes)

        self.logs.log(f"✅ OCR terminé : {len(results)} blocs détectés")
        for i, (text, conf, _box) in enumerate(results[:30], start=1):
            self.logs.log(f"  {i:02d}. ({conf:.2f}) {text}")

        if len(results) > 30:
            self.logs.log(f"… +{len(results) - 30} autres blocs (non affichés)")

        # ✅ FIX zip slicing (zip non indexable)
        if translations:
            self.logs.log("✅ Traduction terminée :")
            orig_texts = [t for (t, _c, _b) in results]
            for i, (orig, tr) in enumerate(list(zip(orig_texts, translations))[:30], start=1):
                self.logs.log(f"  {i:02d}. ORIG: {orig}")
                self.logs.log(f"      FR  : {tr}")
        else:
            self.logs.log("ℹ️ Traduction non effectuée (pas de texte / erreur / clé manquante / local non prêt).")

    def on_ocr_error(self, message: str):
        self.btn_run.setEnabled(True)
        self.btn_choose.setEnabled(True)
        self.progress.setValue(0)

        self.logs.log("❌ Erreur OCR/Traduction :")
        self.logs.log(message)

        if self.current_image_path:
            self.image_viewer.clear_boxes()
            self.image_viewer.set_image(self.current_image_path)
