# app/ui/widgets/image_viewer.py
from __future__ import annotations

from typing import List, Tuple, Optional, Any

from PySide6.QtCore import Qt, QRectF, QPointF
from PySide6.QtGui import QImage, QPainter, QPen, QPixmap, QWheelEvent
from PySide6.QtWidgets import QWidget

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None  # type: ignore


Point = Tuple[int, int]
PolyBox = List[Point]            # [(x,y), (x,y), (x,y), (x,y)]
AnyBox = Any                     # support plusieurs formats


class ImageViewer(QWidget):
    """
    Widget d'affichage d'image + overlay (rectangles / polys OCR)

    ✅ Améliorations :
    - Mode d'affichage:
        * "fit"  : garde le ratio et fait rentrer toute l'image (sans crop)
        * "fill" : remplit la zone (crop possible) en gardant le ratio
    - Zoom molette (autour du centre)
    - Overlay reste cohérent (boxes recalculées avec le même transform)
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(400, 300)
        self.setAutoFillBackground(True)
        

        self._pixmap: Optional[QPixmap] = None
        self._img_w: int = 0
        self._img_h: int = 0

        self._boxes: List[PolyBox] = []

        # Rect où l'image est dessinée dans le widget
        self._target_rect: QRectF = QRectF()

        # Nouveau: mode d'affichage + zoom
        self._view_mode: str = "fit"   # "fit" ou "fill"
        self._zoom: float = 1.0        # 1.0 = normal
        self._zoom_min: float = 0.1
        self._zoom_max: float = 8.0

        # Option: autoriser la molette
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    # ---------------- Public API ----------------

    def set_view_mode(self, mode: str) -> None:
        """
        mode: "fit" (par défaut) ou "fill"
        """
        mode = (mode or "").strip().lower()
        if mode not in ("fit", "fill"):
            mode = "fit"
        self._view_mode = mode
        self._recalc_target_rect()
        self.update()

    def reset_zoom(self) -> None:
        self._zoom = 1.0
        self._recalc_target_rect()
        self.update()

    def clear_boxes(self) -> None:
        self._boxes = []
        self.update()

    def set_boxes(self, boxes: List[AnyBox]) -> None:
        out: List[PolyBox] = []
        for b in (boxes or []):
            nb = self._normalize_box(b)
            if nb:
                out.append(nb)
        self._boxes = out
        self.update()

    def set_image(self, path: str) -> None:
        img = QImage(path)
        if img.isNull():
            self._pixmap = None
            self._img_w = 0
            self._img_h = 0
            self._boxes = []
            self._target_rect = QRectF()
            self.update()
            return

        self._pixmap = QPixmap.fromImage(img)
        self._img_w = img.width()
        self._img_h = img.height()
        self._recalc_target_rect()
        self.update()

    def set_image_array(self, arr, bgr: bool = True) -> None:
        """
        arr: numpy array OpenCV (H,W,3) en BGR (souvent) ou RGB
        bgr=True -> conversion BGR->RGB
        """
        if np is None:
            raise RuntimeError("numpy n'est pas dispo, impossible d'utiliser set_image_array")

        if arr is None:
            self._pixmap = None
            self._img_w = 0
            self._img_h = 0
            self._target_rect = QRectF()
            self.update()
            return

        if not hasattr(arr, "shape"):
            raise TypeError("set_image_array attend un numpy array (shape HxWxC)")

        a = arr
        if a.ndim == 2:
            a = np.stack([a, a, a], axis=-1)
        if a.ndim != 3 or a.shape[2] < 3:
            raise ValueError(f"Array invalide: shape={getattr(a,'shape',None)}")

        a = a[:, :, :3]
        if bgr:
            a = a[:, :, ::-1]

        h, w, _ = a.shape
        a = np.ascontiguousarray(a)
        bytes_per_line = 3 * w
        qimg = QImage(a.data, w, h, bytes_per_line, QImage.Format.Format_RGB888).copy()

        self._pixmap = QPixmap.fromImage(qimg)
        self._img_w = w
        self._img_h = h
        self._recalc_target_rect()
        self.update()

    # ---------------- Qt Events ----------------

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._recalc_target_rect()

    def wheelEvent(self, event: QWheelEvent) -> None:
        """
        Zoom molette : Ctrl+molette recommandé, mais on peut zoomer direct aussi.
        Si tu veux Ctrl obligatoire, décommente le bloc.
        """
        # Si tu veux Ctrl obligatoire :
        # if not (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
        #     return

        delta = event.angleDelta().y()
        if delta == 0:
            return

        step = 1.12 if delta > 0 else 1 / 1.12
        new_zoom = max(self._zoom_min, min(self._zoom_max, self._zoom * step))
        if abs(new_zoom - self._zoom) < 1e-6:
            return

        self._zoom = new_zoom
        self._recalc_target_rect()
        self.update()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)

        # fond
        painter.fillRect(self.rect(), self.palette().window())

        if self._pixmap is None or self._pixmap.isNull():
            return

        # 1) image (source rect dépend du mode fill)
        src_rect = QRectF(0, 0, self._img_w, self._img_h)

        if self._view_mode == "fill":
            # On va dessiner l'image de façon à remplir la target, donc on crop la source si besoin.
            # Compute cropping in image space:
            # target aspect vs image aspect
            tw = float(self._target_rect.width())
            th = float(self._target_rect.height())
            if tw > 0 and th > 0:
                target_aspect = tw / th
                img_aspect = float(self._img_w) / float(self._img_h)

                if img_aspect > target_aspect:
                    # image trop large => crop horizontal
                    new_w = float(self._img_h) * target_aspect
                    x0 = (float(self._img_w) - new_w) / 2.0
                    src_rect = QRectF(x0, 0.0, new_w, float(self._img_h))
                else:
                    # image trop haute => crop vertical
                    new_h = float(self._img_w) / target_aspect
                    y0 = (float(self._img_h) - new_h) / 2.0
                    src_rect = QRectF(0.0, y0, float(self._img_w), new_h)

        painter.drawPixmap(self._target_rect, self._pixmap, src_rect)

        # 2) overlay boxes
        if not self._boxes:
            return

        pen = QPen(Qt.GlobalColor.red)
        pen.setWidth(3)
        painter.setPen(pen)

        # mapping image coords -> widget coords
        sx, sy, ox, oy, src = self._compute_transform(src_rect)

        for poly in self._boxes:
            pts = [QPointF(ox + sx * (float(x) - src.left()), oy + sy * (float(y) - src.top())) for (x, y) in poly]
            if len(pts) >= 2:
                for i in range(len(pts)):
                    painter.drawLine(pts[i], pts[(i + 1) % len(pts)])

    # ---------------- Internal ----------------

    def _recalc_target_rect(self) -> None:
        """Calcule le rectangle où l'image est dessinée (centré, keep aspect ratio) + zoom."""
        if self._pixmap is None or self._pixmap.isNull() or self._img_w <= 0 or self._img_h <= 0:
            self._target_rect = QRectF()
            return

        w = float(self.width())
        h = float(self.height())
        iw = float(self._img_w)
        ih = float(self._img_h)

        if w <= 1 or h <= 1:
            self._target_rect = QRectF()
            return

        # base scale (fit vs fill)
        if self._view_mode == "fill":
            base_scale = max(w / iw, h / ih)  # remplissage (crop possible)
        else:
            base_scale = min(w / iw, h / ih)  # fit (tout visible)

        scale = base_scale * float(self._zoom)

        tw = iw * scale
        th = ih * scale

        x = (w - tw) / 2.0
        y = (h - th) / 2.0

        self._target_rect = QRectF(x, y, tw, th)

    def _compute_transform(self, src_rect: QRectF) -> Tuple[float, float, float, float, QRectF]:
        """
        Retourne (sx, sy, ox, oy, src_rect)
        - sx,sy: scale (source image/crop -> widget)
        - ox,oy: offsets dans le widget
        """
        if self._target_rect.isNull():
            return 1.0, 1.0, 0.0, 0.0, src_rect

        sw = float(src_rect.width()) if src_rect.width() > 0 else float(self._img_w)
        sh = float(src_rect.height()) if src_rect.height() > 0 else float(self._img_h)

        sx = float(self._target_rect.width()) / sw
        sy = float(self._target_rect.height()) / sh
        ox = float(self._target_rect.left())
        oy = float(self._target_rect.top())
        return sx, sy, ox, oy, src_rect

    def _normalize_box(self, box: AnyBox) -> PolyBox:
        """Convertit plusieurs formats de box en poly [(x,y)*4]"""
        if box is None:
            return []

        if np is not None and isinstance(box, np.ndarray):
            box = box.tolist()

        if isinstance(box, dict):
            if all(k in box for k in ("x1", "y1", "x2", "y2")):
                x1, y1, x2, y2 = int(box["x1"]), int(box["y1"]), int(box["x2"]), int(box["y2"])
                return [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
            return []

        if isinstance(box, (list, tuple)) and len(box) == 4 and all(isinstance(v, (int, float)) for v in box):
            x1, y1, x2, y2 = (int(box[0]), int(box[1]), int(box[2]), int(box[3]))
            return [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]

        if isinstance(box, (list, tuple)) and len(box) >= 4:
            if isinstance(box[0], (list, tuple)) and len(box[0]) >= 2:
                pts: PolyBox = []
                for p in list(box)[:4]:
                    if isinstance(p, (list, tuple)) and len(p) >= 2:
                        pts.append((int(p[0]), int(p[1])))
                return pts

        return []
